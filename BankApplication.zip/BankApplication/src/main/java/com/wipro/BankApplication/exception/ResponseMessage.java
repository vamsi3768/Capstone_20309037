package com.wipro.BankApplication.exception;

public class ResponseMessage {
	String Exception;

	public String getException() {
		return Exception;
	}

	public void setException(String exceptionMessage) {
		Exception = exceptionMessage;
	}

}
