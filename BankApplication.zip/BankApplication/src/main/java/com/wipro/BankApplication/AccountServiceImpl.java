package com.wipro.BankApplication;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountServiceInterface {

	@Autowired
	AccountRepository repo;

	@Override
	public List<Account> getAllAccounts() {

		return repo.findAll();
	}

	@Override
	public String transferFunds(int from, int to, double amount) {
		Optional<Account> op = repo.findById(from);
		Optional<Account> opt = repo.findById(to);
		if (op.isPresent() && opt.isPresent()) {
			Account a = (Account) op.get();
			Account b = (Account) opt.get();
			if (a.amount >= amount) {
				a.amount = a.amount - amount;
				b.amount = b.amount + amount;
				repo.save(a);
				repo.save(b);
				System.out.println(a.amount + "" + b.amount);
				return "success";
			} else {
				return "Insufficient Funds";
			}
		} else {
			return "Customer Details Not Matched";
		}
	}

	@Override
	public Account getBalanceOf(int acno) {
		Optional<Account> op = repo.findById(acno);
		if (op.isPresent())
			return (Account) op.get();
		else
			return null;
	}

}
