package com.wipro.BankApplication.exception;

public class RecordsNotFound extends Exception {

	public RecordsNotFound() {

	}
	public RecordsNotFound(String message) {
		super(message);
	}

}
