package com.wipro.BankApplication;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerServiceInterface {

	@Autowired
	CustomerRepository repo;

	@Override
	public String isEmpty() {
		long temp = repo.count();
		if (temp == 0)
			return "Empty";
		else
			return "not empty";
	}

	@Override
	public Customer addCustomer(Customer c) {
		// TODO Auto-generated method stub
		return repo.save(c);
	}

	@Override
	public Customer getCustomer(int id) {
		Optional<Customer> op = repo.findById(id);
		if (op.isPresent())
			return (Customer) op.get();
		else
			return null;
	}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Customer updateCustomer(int id, Customer c) {
		Optional<Customer> op = repo.findById(id);
		if (op.isPresent()) {
			Customer c1 = (Customer) op.get();
			c1.setName(c.getName());
			c1.setCity(c.getCity());
			c1.setAccount(c.getAccount());
			return repo.save(c1);
		} else
			return null;
	}

	@Override
	public String deleteCustomer(int id) {
		Optional<Customer> opt = repo.findById(id);
		if (opt.isPresent()) {
			repo.deleteById(id);
			return "deleted";
		} else
			return "NO Customer matched with given id";
	}

	@Override
	public String deleteAll() {
		repo.deleteAll();
		return "All Deleted";
	}

}
