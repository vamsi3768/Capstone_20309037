package com.wipro.BankApplication;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface CustomerServiceInterface {

	public String isEmpty();

	public Customer addCustomer(Customer c);

	public Customer getCustomer(int id);

	public List<Customer> getAllCustomer();

	public Customer updateCustomer(int id, Customer c);

	public String deleteCustomer(int id);

	public String deleteAll();
}
