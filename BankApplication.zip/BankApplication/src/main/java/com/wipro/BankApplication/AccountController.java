package com.wipro.BankApplication;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/account")
public class AccountController {
	@Autowired
	AccountServiceInterface service;
	@Autowired
	AccountRepository repo;

	@GetMapping("/getall")
	public ResponseEntity<?> getAllAccounts() {
		List<Account> a = service.getAllAccounts();
		if (a != null)
			return new ResponseEntity<>(a, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/transfer/{from}/{to}/{amount}")
	public ResponseEntity<?> transferFunds(@PathVariable("from") int from, @PathVariable("to") int to,
			@PathVariable("amount") double amount) {
		String s = service.transferFunds(from, to, amount);
		if (s == "success")
			return new ResponseEntity<>(s, HttpStatus.OK);
		else if (s == "insuficient funds")
			return new ResponseEntity<>("Insufficient Funds", HttpStatus.NOT_ACCEPTABLE);
		else
			return new ResponseEntity<>("Customer Details not Matched", HttpStatus.NOT_ACCEPTABLE);
	}

	@GetMapping("/getbal/{acno}")
	public ResponseEntity<?> getBalanceOf(@PathVariable("acno") int acno) {
		Account a = service.getBalanceOf(acno);
		if (a != null)
			return new ResponseEntity<>(a, HttpStatus.OK);
		else
			return new ResponseEntity<>("customer details not matched with given id", HttpStatus.NOT_FOUND);
	}
}
