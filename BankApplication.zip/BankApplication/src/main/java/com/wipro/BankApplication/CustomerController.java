package com.wipro.BankApplication;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerServiceInterface service;
	@Autowired
	CustomerRepository repo;

	@GetMapping("/isempty")
	public ResponseEntity<?> isEmpty() {
		String s = service.isEmpty();
		if (s != "0")
			return new ResponseEntity<>("not empty", HttpStatus.OK);
		else
			return new ResponseEntity<>("Empty", HttpStatus.OK);
	}

	@PostMapping("/add")
	public ResponseEntity<?> addCustomer(@RequestBody Customer c) {
		Customer c1 = service.addCustomer(c);
		if (c1 != null)
			return new ResponseEntity<>(c1, HttpStatus.CREATED);
		else
			return new ResponseEntity<>("Customer object is not Created", HttpStatus.BAD_REQUEST);
	}

	@GetMapping("/getall")
	public ResponseEntity<?> getAllCustomer() {
		List<Customer> l = service.getAllCustomer();
		if (l != null)
			return new ResponseEntity<>(l, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<?> getCustomerById(@PathVariable("id") int id) {
		Customer c = service.getCustomer(id);
		if (c != null)
			return new ResponseEntity<>(c, HttpStatus.OK);
		else
			return new ResponseEntity<>("Customer not displayed given id", HttpStatus.NOT_FOUND);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateCustomerById(@PathVariable("id") int id, @RequestBody Customer c) {
		List<Customer> l = service.getAllCustomer();
		Customer c1 = service.updateCustomer(id, c);
		if (c1 != null)
			return new ResponseEntity<>(c, HttpStatus.OK);
		else if (c1 != l)
			return new ResponseEntity<>("Customer not found", HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>("Customer not updated", HttpStatus.NOT_MODIFIED);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteCustomerById(@PathVariable("id") int id) {
		String msg = service.deleteCustomer(id);
		return new ResponseEntity<>(msg, HttpStatus.OK);
	}

	@DeleteMapping("/deleteall")
	public ResponseEntity<?> deleteAll() {
		service.deleteAll();
		return new ResponseEntity<>("Deleted Customer data", HttpStatus.OK);
	}

}
