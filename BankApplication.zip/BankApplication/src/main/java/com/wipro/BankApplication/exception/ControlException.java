package com.wipro.BankApplication.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class ControlException {

	@ExceptionHandler(RecordsNotFound.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ResponseBody
	ResponseMessage handleRecordsNotFoundException(RecordsNotFound ErrorMessage) {
		ResponseMessage exce = new ResponseMessage();
		exce.setException(ErrorMessage.getMessage());
		return exce;
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	ResponseMessage handleSystemException(Exception exception, HttpServletRequest status) {
		ResponseMessage exce1 = new ResponseMessage();
		exce1.setException(exception.getMessage());
		return exce1;
	}
}
