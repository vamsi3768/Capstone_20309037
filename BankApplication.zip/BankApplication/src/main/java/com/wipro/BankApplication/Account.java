package com.wipro.BankApplication;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AccountTable")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int acno;
	String actype;
	double amount;

	public int getAcno() {
		return acno;
	}

	public void setAcno(int acno) {
		this.acno = acno;
	}

	public String getActype() {
		return actype;
	}

	public void setActype(String actype) {
		this.actype = actype;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Account [acno=" + acno + ", actype=" + actype + ", amount=" + amount + "]";
	}

	public Account(int acno, String actype, double amount) {
		super();
		this.acno = acno;
		this.actype = actype;
		this.amount = amount;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

}
