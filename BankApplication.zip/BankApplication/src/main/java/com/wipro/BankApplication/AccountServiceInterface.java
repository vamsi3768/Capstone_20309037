package com.wipro.BankApplication;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface AccountServiceInterface {

	public List<Account> getAllAccounts();

	public String transferFunds(int from, int to, double amount);

	public Account getBalanceOf(int acno);

}
