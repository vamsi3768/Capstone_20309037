package com.wipro.BankApplication;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class AccountServiceUnitTest {

	@InjectMocks
	AccountServiceImpl service;

	@Mock
	AccountRepository repo;

	@Mock
	CustomerRepository custrepo;

	@Test
	public void testGetAllAccounts() {
		List<Account> list = new ArrayList<>();
		when(repo.findAll()).thenReturn(list);
		List<Account> l = service.getAllAccounts();
		assert (l).isEmpty();
	}


	@Test
	public void testTransferFunds() {
		double amount = 200;
		Account a1 = new Account(1, "savings", 700);
		Account a2 = new Account(2, "savings", 800);
		Optional<Account> opt = Optional.of(a1);
		when(repo.findById(any(Integer.class))).thenReturn(opt);
		Optional<Account> opt1 = Optional.of(a2);
		when(repo.findById(any(Integer.class))).thenReturn(opt1);
		String s = service.transferFunds(1, 2, amount);
		Assertions.assertEquals("success", s);

	}

	@Test
	public void testGetBalanceOf() {
		int acno = 0;
		Account a = new Account();
		Optional<Account> opt = repo.findById(acno);
		if (opt.isEmpty() != true) {
			when(opt.get()).thenReturn(a);
		}
		Account a1 = service.getBalanceOf(acno);
		Assertions.assertEquals(null, a1);
	}
}
