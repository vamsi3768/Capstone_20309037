package com.wipro.BankApplication;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = AccountController.class)
public class AccountControllerUnitTest {

	@Autowired
	MockMvc mvc;

	@MockBean
	AccountServiceInterface service;
	@MockBean
	AccountRepository repo;

	ObjectMapper mapper = new ObjectMapper();
	
	@Test
	public void shouldReturnAllAccounts() throws Exception {
		List<Account> ac = new ArrayList<>();
		ac.add(new Account(1, "saving", 800.0));
		ac.add(new Account(2, "saving", 400.0));
		when(service.getAllAccounts()).thenReturn(ac);

		String list = "[{\"acno\":" + 1 + ",\"actype\":\"saving\",\"amount\":" + 800.0 + "}," + "{\"acno\":" + 2
				+ ",\"actype\":\"saving\",\"amount\":" + 400.0 + "}]";

		MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/account/getall").accept(MediaType.ALL)).andReturn();
		MockHttpServletResponse res = result.getResponse();
		String content = res.getContentAsString();
		Assertions.assertEquals(list, content);
	}


	@Test
	public void shouldTransferFunds() throws Exception {
		Customer c1 = new Customer(1, "vamsi", "puttur", new Account(1, "saving", 3000.0));
		Customer c2 = new Customer(2, "Krishna", "Tirupati", new Account(2, "saving", 1000.0));
		int from = c1.account.acno;
		int to = c2.account.acno;
		double amount = 100;

		when(service.transferFunds(from, to, amount)).thenReturn("success");
		MvcResult result = mvc
				.perform(MockMvcRequestBuilders.get("/account/transfer/{from}/{to}/{amount}", from, to, amount))
				.andReturn();
		String content = result.getResponse().getContentAsString();
		Assertions.assertEquals("success", content);
	}

	@Test
	public void shouldGetBalanceOf() throws Exception {
		int acno = 1;
		Account a = new Account(1, "saving", 800.0);
		when(service.getBalanceOf(acno)).thenReturn(a);
		MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/account/getbal/{acno}", acno)).andReturn();
		String content = result.getResponse().getContentAsString();
		Assertions.assertEquals(mapper.writeValueAsString(a), content);
	}



}
