package com.wipro.BankApplication;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
@SpringBootTest(webEnvironment =WebEnvironment.RANDOM_PORT,classes=BankApplication.class)
@ExtendWith(MockitoExtension.class)
public class CustomerControllerIntegrationTest {
	@LocalServerPort
	private int localport;
	@Autowired
	private TestRestTemplate template;
	
	@Test
	public void testShouldReturnEmptyList() {
		ResponseEntity<?> entity=template.getForEntity("http://localhost:" +localport + "/customer/getall", List.class);
		Assertions.assertEquals(200, entity.getStatusCodeValue());
}
}
