package com.wipro.BankApplication;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers=CustomerController.class)
public class CustomerControllerUnitTest {

	@Autowired
	MockMvc mvc;
	
	@MockBean
	CustomerRepository repo;
	
	@MockBean
	CustomerServiceInterface service;
	ObjectMapper mapper=new ObjectMapper();
	
	@Test
	public void shouldReturnAllCustomerTest() throws Exception{
		List<Customer> l=new ArrayList<>();
		l.add(new Customer(1,"vamsi","tirupati",null));
		l.add(new Customer(2,"raj","puttur",null));
		when(service.getAllCustomer()).thenReturn(l);
		
		String list="[{\"id\":"+1+",\"name\":\"vamsi\",\"city\":\"tirupati\",\"account\":"+null+"}," + 
				"{\"id\":"+2+",\"name\":\"raj\",\"city\":\"puttur\",\"account\":"+null+"}]";
				
				MvcResult result=mvc.perform(MockMvcRequestBuilders.get("/customer/getall")
						.accept(MediaType.ALL)).andReturn();
	   MockHttpServletResponse resp=result.getResponse();
	   String content=resp.getContentAsString();
	   Assertions.assertEquals(list, content);
	}
	@Test
	public void shouldAddCustomerTest() throws Exception{
		Customer c=new Customer(1,"vamsi","tirupati",new Account(1,"saving",3000.0));
		
		when(service.addCustomer(any(Customer.class))).thenReturn(c);
		MvcResult result=mvc.perform(MockMvcRequestBuilders.post("/customer/add")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(c))
				.accept(MediaType.ALL))
				.andReturn();
				MockHttpServletResponse resp=result.getResponse();
				String content=resp.getContentAsString();
		Assertions.assertEquals(mapper.writeValueAsString(c),content);
	}
	@Test
	public void shouldGetCustomerByIdTest() throws Exception{
		int id=1;
		Customer c=new Customer(1,"vamsi","puttur",new Account(1,"saving",3000.0));
		when(service.getCustomer(id)).thenReturn(c);
		MvcResult result=mvc.perform(MockMvcRequestBuilders.get("/customer/get/{id}",id)).andReturn();
		String content=result.getResponse().getContentAsString();
		Assertions.assertEquals(mapper.writeValueAsString(c), content);
	}
	@Test
	public void shouldUpdateCustomerByIdTest() throws Exception{
		int id=1;
		Customer c=new Customer(1,"vamsi","puttur",new Account(1,"saving",3000.0));
		
		when(service.updateCustomer(any(Integer.class), any(Customer.class))).thenReturn(c);
		MvcResult result=mvc.perform(MockMvcRequestBuilders.put("/customer/update/{id}",id)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(c))
				.accept(MediaType.ALL))
				.andReturn();
				String content=result.getResponse().getContentAsString();
		Assertions.assertEquals(mapper.writeValueAsString(c),content);
	}
	@Test
	public void shouldDeleteCustomerByIdTest() throws Exception{
		int id=1;
		when(service.deleteCustomer(id)).thenReturn("Deleted");
		MvcResult result=mvc.perform(MockMvcRequestBuilders.delete("/customer/delete/{id}",id)).andReturn();
		String content=result.getResponse().getContentAsString();
		Assertions.assertEquals("Deleted", content);
	}
	
}
