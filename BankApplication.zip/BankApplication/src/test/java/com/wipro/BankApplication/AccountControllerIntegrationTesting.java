package com.wipro.BankApplication;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
@ExtendWith(MockitoExtension.class)
@SpringBootTest(webEnvironment =WebEnvironment.RANDOM_PORT, classes= BankApplication.class)
public class AccountControllerIntegrationTesting {
	@LocalServerPort
	private int localport;
	@Autowired
	private TestRestTemplate testresttemplate;
	@Autowired
	AccountRepository repo;
	@Test
	public void testShouldReturnList() {
		ResponseEntity<?> entity=testresttemplate.getForEntity("http://localhost:" +localport + "/account/getall", List.class);
		Assertions.assertEquals(200, entity.getStatusCodeValue());
	}
	
}
