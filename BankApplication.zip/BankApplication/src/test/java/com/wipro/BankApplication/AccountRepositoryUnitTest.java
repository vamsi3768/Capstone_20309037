package com.wipro.BankApplication;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit.jupiter.SpringExtension;



@ExtendWith(SpringExtension.class)
@DataJpaTest
public class AccountRepositoryUnitTest {

	@Autowired
	TestEntityManager manager;
	@Autowired
	AccountRepository repo;
	@Test
	public void TestFindAll() {
		repo.save(new Account(1,"saving",700));
		List<Account> l=repo.findAll();
		Assertions.assertEquals(l.size(),1);
	}
	@Test
	public void TestFindById() {
		int acno=1;
		repo.save(new Account(1,"saving",700));
		Account a1=repo.save(new Account(1,"saving",700));
		Optional<Account> opt=repo.findById(acno);
		if(opt.isPresent())
			Assertions.assertEquals(opt.get(), a1);
 	}
}
