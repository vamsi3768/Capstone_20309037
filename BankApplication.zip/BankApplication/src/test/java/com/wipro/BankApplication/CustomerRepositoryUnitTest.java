package com.wipro.BankApplication;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@DataJpaTest
public class CustomerRepositoryUnitTest {


	@Autowired
	TestEntityManager manager;
	@Autowired
	CustomerRepository repo;
	@Test
	public void testFindAll() {
		repo.save(new Customer(1,  "Vamsi","puttur",null));
		List<Customer> l=repo.findAll();
		Assertions.assertEquals(l.size(), 1);
	}	
	@Test
	public void testCount() {
		repo.save(new Customer(1,  "Vamsi","tirupati",null));
		long L=repo.count();
		Assertions.assertEquals(L, 1);
	}
	@Test
	public void testFindById() {
		int id=1;
		repo.save(new Customer(1,  "Vamsi","tirupati",null));
		Customer c1=new Customer(1,"vamsi","puttur",null);
		Optional<Customer> opt=repo.findById(id);
		if(opt.isPresent())
		   Assertions.assertEquals(opt.get(), c1);
	}
	@Test
	public void testDeleteAll() {
		repo.save(new Customer(1,  "Vamsi","puttur",null));
		repo.deleteAll();
		List<Customer> l=repo.findAll();
		Assertions.assertEquals(l.size(), 0);
	}	
}
