package com.wipro.BankApplication;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class CustomerServiceUnitTest {
	
	@InjectMocks
	CustomerServiceImpl service;
	
	@Mock
	CustomerRepository repo;
	
	@Test
	public void testIsEmpty() {
		long temp=0, temp1=1;
		when(repo.count()).thenReturn(temp);
		String s=service.isEmpty();
		if(s=="Empty")
			temp1=0;
		Assertions.assertEquals(temp, temp1);
	}

	@Test
	public void testGetAllCustomer() {
		List<Customer> list=new ArrayList<>();
		when(repo.findAll()).thenReturn(list);
		List<Customer> l=service.getAllCustomer();
		assert(l).isEmpty();
	}
	@Test
	public void testaddCustomer() {
		Customer c=new Customer();
		when(repo.save(c)).thenReturn(c);
		Customer c1=service.addCustomer(c);
		Assertions.assertEquals(c, c1);
	}
	@Test
	public void testGetCustomer() {
		int id=1;
		Customer c=new Customer(1,"vamsi","tirupati",null);
		Optional<Customer> opt=Optional.of(c);
		when(repo.findById(any(Integer.class))).thenReturn(opt);
		Customer c1=service.getCustomer(id);
		Assertions.assertEquals(c, c1);
	}
	@Test
	public void testUpdateCustomer() {
		Customer c1=new Customer(1,"vamsi","tirupati",null);
		Customer c2=new Customer(1,"krishna","Chennai",null);
		Optional<Customer> opt=Optional.of(c1);
		when(repo.findById(any(Integer.class))).thenReturn(opt);
		service.updateCustomer(1, c2);
		Assertions.assertNotEquals(c1, c2);;
	}
	@Test
	public void testDeleteCustomerById() {
		Customer c1=new Customer(1,"vamsi","tirupati",null);
		Optional<Customer> opt=Optional.of(c1);
		when(repo.findById(any(Integer.class))).thenReturn(opt);
		String s=service.deleteCustomer(1);
		Assertions.assertEquals("deleted", s);
	}
	@Test
	public void testDeleteAllCustomers() {
		String s=service.deleteAll();
		Assertions.assertEquals("All Deleted", s);
	}



}
